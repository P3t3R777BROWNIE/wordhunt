# WordHunt Full Stack

## Structure
- client/ — React + Vite frontend
- server/ — Node.js + Express + Socket.IO backend (Postgres + Redis)

## Run locally

### 1) Start Postgres + Redis

```bash
cd server
docker-compose up -d
```

### 2) Backend

```bash
cd server
npm install
npx prisma migrate dev --name init
npm run dev
```

Backend: http://localhost:5000

### 3) Frontend

```bash
cd ../client
npm install
npm run dev
```

Frontend: http://localhost:5173

## Frontend → Backend configuration
Create `client/.env`:

```
VITE_API_URL=http://localhost:5000
```

If your frontend uses Socket.IO directly, connect to the same base URL:

- `http://localhost:5000`
