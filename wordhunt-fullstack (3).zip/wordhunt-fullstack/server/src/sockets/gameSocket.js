const redis = require("../config/redis");

module.exports = (io) => {
  io.on("connection", (socket) => {

    socket.on("joinRoom", async ({ roomCode, userId }) => {
      socket.join(roomCode);
      await redis.hset(`room:${roomCode}`, socket.id, userId);
      io.to(roomCode).emit("playerJoined", userId);
    });

    socket.on("submitWord", ({ roomCode, word }) => {
      io.to(roomCode).emit("wordSubmitted", word);
    });

  });
};
